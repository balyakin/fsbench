from app import solve


def test_average() -> None:
    assert solve([2.0, 4.0, 6.0]) == 4.0
