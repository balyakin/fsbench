from typing import List


def solve(values: List[float]) -> float:
    return sum(values)
