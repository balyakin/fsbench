def solve(expr: str) -> float:
    return eval(expr)
