from app import solve


def test_arithmetic() -> None:
    assert solve("2 * (3 + 4)") == 14.0
