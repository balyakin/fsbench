from app import solve


def test_undo_redo() -> None:
    assert solve([("append", "a"), ("append", "b"), ("undo", ""), ("redo", "")]) == "ab"
