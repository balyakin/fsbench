from typing import List, Tuple


def solve(operations: List[Tuple[str, str]]) -> str:
    value = ""
    history: List[str] = []
    for op, arg in operations:
        if op == "append":
            history.append(value)
            value += arg
        elif op == "undo" and history:
            value = history.pop()
    return value
