VALUES = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100}


def solve(value: str) -> int:
    return sum(VALUES[ch] for ch in value)
