from app import solve


def test_subtractive() -> None:
    assert solve("XIV") == 14
