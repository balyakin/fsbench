from app import solve


def test_stable_key() -> None:
    assert solve({"b": 2, "a": 1}) == solve({"a": 1, "b": 2})
