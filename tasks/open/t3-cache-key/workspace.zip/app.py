from typing import Any, Dict
import json


def solve(payload: Dict[str, Any]) -> str:
    return json.dumps(payload)
