from typing import Dict


def solve(query: str) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for part in query.split("&"):
        if "=" in part:
            key, value = part.split("=", 1)
            result[key] = value
    return result
