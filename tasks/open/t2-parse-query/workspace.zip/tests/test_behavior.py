from app import solve


def test_parse_query() -> None:
    assert solve("name=Alice+Smith&city=New%20York") == {"name": "Alice Smith", "city": "New York"}
