from typing import Dict, List


def solve(graph: Dict[str, List[str]]) -> List[str]:
    return list(graph)
