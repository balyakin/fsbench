from app import solve


def test_topological_order() -> None:
    assert solve({"build": ["test"], "test": ["lint"], "lint": []}) == ["lint", "test", "build"]
