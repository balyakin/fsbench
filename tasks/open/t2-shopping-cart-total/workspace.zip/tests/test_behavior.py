from app import solve


def test_cart_total() -> None:
    assert solve([{"price": 2.5, "quantity": 2}, {"price": 1.0, "quantity": 3}]) == 8.0
