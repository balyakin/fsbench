from typing import Dict, List


def solve(items: List[Dict[str, float]]) -> float:
    return round(sum(item["price"] for item in items), 2)
