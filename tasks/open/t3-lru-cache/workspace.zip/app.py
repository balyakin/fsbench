from typing import List, Optional, Tuple


def solve(operations: List[Tuple[str, int, Optional[int]]], capacity: int) -> List[int]:
    cache = {}
    output: List[int] = []
    for op, key, value in operations:
        if op == "put" and value is not None:
            cache[key] = value
        if op == "get":
            output.append(cache.get(key, -1))
    return output
