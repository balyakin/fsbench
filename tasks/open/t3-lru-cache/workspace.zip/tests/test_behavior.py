from app import solve


def test_lru_eviction() -> None:
    ops = [("put", 1, 10), ("put", 2, 20), ("get", 1, None), ("put", 3, 30), ("get", 2, None)]
    assert solve(ops, 2) == [10, -1]
