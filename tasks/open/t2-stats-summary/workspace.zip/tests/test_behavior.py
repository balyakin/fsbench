from app import solve


def test_summary() -> None:
    assert solve([2, 4, 9]) == {"min": 2, "max": 9, "mean": 5.0}
