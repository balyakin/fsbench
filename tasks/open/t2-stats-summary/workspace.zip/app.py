from typing import Dict, List


def solve(values: List[int]) -> Dict[str, float]:
    return {"min": min(values), "max": max(values), "mean": sum(values)}
