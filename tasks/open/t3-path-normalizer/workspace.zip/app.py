def solve(path: str) -> str:
    return path.replace("//", "/")
