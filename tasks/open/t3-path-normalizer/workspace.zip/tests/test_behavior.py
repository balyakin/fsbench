from app import solve


def test_normalizes_path() -> None:
    assert solve("/a//b/./c/../d") == "/a/b/d"
