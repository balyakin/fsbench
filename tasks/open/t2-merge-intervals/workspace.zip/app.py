from typing import List, Tuple


def solve(intervals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    return sorted(intervals)
