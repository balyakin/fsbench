from app import solve


def test_merge_intervals() -> None:
    assert solve([(5, 7), (1, 3), (2, 4)]) == [(1, 4), (5, 7)]
