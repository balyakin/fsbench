from app import solve


def test_adds_positive_numbers() -> None:
    assert solve(2, 3) == 5
