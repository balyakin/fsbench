from app import solve


def test_normalizes_name() -> None:
    assert solve("  Alice  ") == "alice"
