def solve(value: str) -> str:
    return value.strip()
