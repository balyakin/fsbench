from app import solve


def test_date_window() -> None:
    assert solve("2026-01-30", 3) == ["2026-01-30", "2026-01-31", "2026-02-01"]
