from typing import List


def solve(start: str, days: int) -> List[str]:
    prefix = start[:-2]
    day = int(start[-2:])
    return [f"{prefix}{day + offset:02d}" for offset in range(days)]
